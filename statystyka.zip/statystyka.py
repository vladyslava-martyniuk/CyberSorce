from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

folder = Path(__file__).resolve().parent
data = pd.read_csv(folder / "cybersecurity_network_traffic_synthetic.csv")
columns = [
    "Flow_Duration",
    "Total_Fwd_Packets",
    "Total_Backward_Packets",
    "Fwd_Packet_Length_Mean",
    "Bwd_Packet_Length_Mean",
    "Flow_Bytes_per_s",
    "Flow_Packets_per_s",
    "Flow_IAT_Mean",
]
numeric = data[columns].apply(pd.to_numeric, errors="coerce")
stats = pd.DataFrame({
    "count": numeric.count(),
    "mean": numeric.mean(),
    "median": numeric.median(),
    "mode": numeric.mode(dropna=True).iloc[0],
    "std": numeric.std(),
    "min": numeric.min(),
    "Q1": numeric.quantile(0.25),
    "Q3": numeric.quantile(0.75),
    "max": numeric.max(),
    "skewness": numeric.skew(),
})
stats.index.name = "parameter"
stats.round(3).to_csv(folder / "statystyka.csv", encoding="utf-8-sig")

sns.set_theme(style="whitegrid")
fig, axes = plt.subplots(2, 4, figsize=(18, 9))
for ax, col in zip(axes.flat, columns):
    sns.histplot(numeric[col].dropna(), bins=18, ax=ax, color="#3979a6", edgecolor="white")
    ax.axvline(numeric[col].mean(), color="#d95c3f", linewidth=1.6, label="Mean")
    ax.axvline(numeric[col].median(), color="#24684d", linewidth=1.6, linestyle="--", label="Median")
    ax.set_title(col, fontsize=11)
    ax.set_xlabel("")
    ax.set_ylabel("Frequency")
    ax.legend(fontsize=8)
fig.suptitle("Network Traffic: Statistical Distributions", fontsize=17, fontweight="bold")
fig.tight_layout(rect=(0, 0, 1, 0.955))
fig.savefig(folder / "statystyka_rozpodil.png", dpi=180, bbox_inches="tight")
plt.close(fig)
print(stats.round(2).to_string())
