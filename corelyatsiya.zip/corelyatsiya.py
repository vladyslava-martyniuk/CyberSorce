from pathlib import Path
import sys
import pandas as pd

columns = [
    "Flow_Duration",
    "Total_Fwd_Packets",
    "Total_Backward_Packets",
    "Fwd_Packet_Length_Mean",
    "Bwd_Packet_Length_Mean",
    "Flow_Bytes_per_s",
    "Flow_Packets_per_s",
    "Flow_IAT_Mean",
]

source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("cybersecurity_network_traffic_synthetic.csv")
df = pd.read_csv(source)
corr = df[columns].corr(method="pearson")

pairs = [
    (a, b, float(corr.loc[a, b]))
    for i, a in enumerate(columns)
    for b in columns[i + 1:]
]

positive = sorted((p for p in pairs if p[2] > 0), key=lambda p: -p[2])
negative = sorted((p for p in pairs if p[2] < 0), key=lambda p: p[2])

print(f"Записів: {len(df)}. Проаналізовано {len(columns)} кількісних ознак.")
print("\nКореляційна матриця:\n", corr.round(3).to_string())
print("\nНайсильніші позитивні зв'язки:")
for a, b, r in positive[:3]:
    print(f"{a} — {b}: r={r:+.3f}")
print("\nНайсильніші негативні зв'язки:")
for a, b, r in negative[:3]:
    print(f"{a} — {b}: r={r:+.3f}")
