from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

columns = [
    "Flow_Duration",
    "Total_Fwd_Packets",
    "Total_Backward_Packets",
    "Fwd_Packet_Length_Mean",
    "Bwd_Packet_Length_Mean",
    "Flow_Bytes_per_s",
    "Flow_Packets_per_s",
    "Flow_IAT_Mean",
]
labels = ["DURATION", "FWD_PKTS", "BWD_PKTS", "FWD_LEN", "BWD_LEN", "BYTES/S", "PKTS/S", "IAT"]

source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("cybersecurity_network_traffic_synthetic.csv")
df = pd.read_csv(source)
corr = df[columns].corr(method="pearson")

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})
fig, ax = plt.subplots(figsize=(9.4, 7.3), dpi=180)
fig.patch.set_facecolor("white")
values = corr.to_numpy()
image = ax.imshow(values, vmin=-1, vmax=1, cmap="RdBu_r", interpolation="none")
ax.set_xticks(range(len(labels)), labels, rotation=43, ha="right", rotation_mode="anchor")
ax.set_yticks(range(len(labels)), labels)
ax.tick_params(axis="both", length=0)
ax.set_xticks(np.arange(-0.5, len(labels), 1), minor=True)
ax.set_yticks(np.arange(-0.5, len(labels), 1), minor=True)
ax.grid(which="minor", color="white", linewidth=1.5)
ax.tick_params(which="minor", left=False, bottom=False)
for i in range(len(columns)):
    for j in range(len(columns)):
        value = float(values[i, j])
        ax.text(j, i, f"{value:+.3f}" if i != j else "1.000", ha="center", va="center", fontsize=9.4, color="white" if abs(value) >= 0.7 else "#15283C", fontweight="bold" if abs(value) > 0.9 else "normal")
colorbar = fig.colorbar(image, ax=ax, fraction=0.042, pad=0.04)
colorbar.set_label("Коефіцієнт кореляції Пірсона (r)")
ax.set_title("Кореляційна матриця мережевого трафіку", fontweight="bold", fontsize=14, pad=14)
fig.subplots_adjust(left=0.19, right=0.90, bottom=0.17, top=0.91)
output = Path(__file__).with_name("corelyatsiya_heatmap.png")
fig.savefig(output, dpi=180, bbox_inches="tight", facecolor="white")
plt.close(fig)
print(output)
